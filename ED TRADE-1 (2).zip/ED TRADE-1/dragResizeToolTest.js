// const canvas_img = document.getElementById("canvas-img");
// const context_img = canvas_img.getContext("2d");

// const canvas_tool = document.getElementById("canvas-tool");
// const context_tool = canvas_tool.getContext("2d");

// canvas_img.width = 400;
// canvas_img.height = 400;

// canvas_tool.width = 400;
// canvas_tool.height = 400;

// canvas_img.style.border = '1px solid red';
// canvas_tool.style.border = '1px solid black';

// const img = new Image();

// img.src = "dog.jpg";

// img.onload = function(){
//     context_img.drawImage(img, 0, 0, canvas_img.width, canvas_img.height);
// };

// let isDragging = false;
// let isResizing = false;
// let start_x;
// let start_y;
// let resizeHandleHovered = false;
// let tool_shape = { x: 100, y: 100, width: 200, height: 200 };
// const resizeHandleRadius = 8;

// function is_mouse_in_shape(mouse_x, mouse_y, tool_shape) {
//     let tool_shape_left = tool_shape.x;
//     let tool_shape_right = tool_shape.x + tool_shape.width;
//     let tool_shape_top = tool_shape.y;
//     let tool_shape_bottom = tool_shape.y + tool_shape.height;

//     if (mouse_x > tool_shape_left && mouse_x < tool_shape_right && mouse_y > tool_shape_top && mouse_y < tool_shape_bottom) {
//         return true;
//     } else {
//         return false;
//     }
// }

// function is_mouse_in_resize_handle(mouse_x, mouse_y) {
//     let handles = getResizeHandles();
//     for (let handle of handles) {
//         let dist = Math.sqrt((mouse_x - handle.x) ** 2 + (mouse_y - handle.y) ** 2);
//         if (dist <= resizeHandleRadius) {
//             resizeHandleHovered = true;
//             return true;
//         }
//     }
//     return false;
// }

// function getResizeHandles() {
//     return [
//         { x: tool_shape.x, y: tool_shape.y },
//         { x: tool_shape.x + tool_shape.width, y: tool_shape.y },
//         { x: tool_shape.x, y: tool_shape.y + tool_shape.height },
//         { x: tool_shape.x + tool_shape.width, y: tool_shape.y + tool_shape.height },
//     ];
// }

// canvas_tool.addEventListener('mousedown', function (event) {
//     let mouseX = event.pageX - canvas_tool.offsetLeft;
//     let mouseY = event.pageY - canvas_tool.offsetTop;

//     if (is_mouse_in_shape(mouseX, mouseY, tool_shape)) {
//         isDragging = true;
//     } else if (is_mouse_in_resize_handle(mouseX, mouseY)) {
//         isResizing = true;
//     }
//     start_x = mouseX;
//     start_y = mouseY;


// });

// canvas_tool.addEventListener('mousemove', function (event) {
//     let mouseX = event.pageX - canvas_tool.offsetLeft;
//     let mouseY = event.pageY - canvas_tool.offsetTop;

//     if (isResizing) {
//         let dx = mouseX - start_x;
//         let dy = mouseY - start_y;
//         console.log("x" + dx + "y" + dy)

//         tool_shape.width += dx;
//         tool_shape.height += dy;

//         console.log("x" + tool_shape.width);
//         console.log("y" + tool_shape.height);

//         start_x = mouseX;
//         start_y = mouseY;

//         draw_tool();
//     } else if (isDragging) {
//         let dx = mouseX - start_x;
//         let dy = mouseY - start_y;

//         tool_shape.x += dx;
//         tool_shape.y += dy;

//         start_x = mouseX;
//         start_y = mouseY;

//         draw_tool();
//     } else {
//         resizeHandleHovered = is_mouse_in_resize_handle(mouseX, mouseY);
//     }
// });

// canvas_tool.addEventListener('mouseup', function () {
//     isDragging = false;
//     isResizing = false;
// });

// function draw_tool() {
//     context_tool.clearRect(0, 0, canvas_tool.width, canvas_tool.height);

//     if (resizeHandleHovered || isResizing) {
//         let handles = getResizeHandles();
//         context_tool.fillStyle = 'blue';
//         for (let handle of handles) {
//             context_tool.beginPath();
//             context_tool.arc(handle.x, handle.y, resizeHandleRadius, 0, 2 * Math.PI);
//             context_tool.fill();
//         }
//     }

//     context_tool.fillStyle = "rgba(255, 165, 0, 0.3)";
//     context_tool.fillRect(tool_shape.x, tool_shape.y, tool_shape.width, tool_shape.height);
// }

// draw_tool();

// function reload() {
//     context_tool.clearRect(0, 0, canvas_tool.width, canvas_tool.height);
//     context_tool.fillStyle = "rgba(255, 165, 0, 0.3)";
//     context_tool.fillRect(100, 100, 200, 200);
// }

// const btn_reset = document.querySelector("#reset");
// btn_reset.addEventListener("click", reload);
const canvas_img = document.getElementById("canvas-img");
const context_img = canvas_img.getContext("2d");

const canvas_tool = document.getElementById("canvas-tool");
const context_tool = canvas_tool.getContext("2d");

canvas_img.width = 400;
canvas_img.height = 400;

canvas_tool.width = 400;
canvas_tool.height = 400;

canvas_img.style.border = '1px solid red';
canvas_tool.style.border = '1px solid black';

const img = new Image();

img.src = "img/2.jpg";

img.onload = function () {
    context_img.drawImage(img, 0, 0, canvas_img.width, canvas_img.height);
};

let isResizing = false;
let isDragging = false;
let start_x;
let start_y;
let resizeHandleHovered = false;
const resizeHandleRadius = 10;
let tool_shape = { x: 100, y: 100, width: 200, height: 200 };

function is_mouse_in_shape(mouse_x, mouse_y, tool_shape) {
    let tool_shape_left = tool_shape.x;
    let tool_shape_right = tool_shape.x + tool_shape.width;
    let tool_shape_top = tool_shape.y;
    let tool_shape_bottom = tool_shape.y + tool_shape.height;

    return mouse_x > tool_shape_left && mouse_x < tool_shape_right && mouse_y > tool_shape_top && mouse_y < tool_shape_bottom;
}

function is_mouse_in_resize_handle(mouse_x, mouse_y) {
    let handles = getResizeHandles();
    for (let handle of handles) {
        let dist = Math.sqrt((mouse_x - handle.x) ** 2 + (mouse_y - handle.y) ** 2);
        if (dist <= resizeHandleRadius) {
            resizeHandleHovered = true;
            return true;
        }
    }
    return false;
}

function getResizeHandles() {
    return [
        { x: tool_shape.x, y: tool_shape.y },
        { x: tool_shape.x + tool_shape.width, y: tool_shape.y },
        { x: tool_shape.x, y: tool_shape.y + tool_shape.height },
        { x: tool_shape.x + tool_shape.width, y: tool_shape.y + tool_shape.height },
    ];
}

canvas_tool.addEventListener('mousedown', function (event) {
    let mouseX = event.pageX - canvas_tool.offsetLeft;
    let mouseY = event.pageY - canvas_tool.offsetTop;

    if (is_mouse_in_shape(mouseX, mouseY, tool_shape)) {
        isDragging = true;
    } else if (is_mouse_in_resize_handle(mouseX, mouseY)) {
        isResizing = true;
    }
    start_x = mouseX;
    start_y = mouseY;
});

canvas_tool.addEventListener('mousemove', function (event) {
    let mouseX = event.pageX - canvas_tool.offsetLeft;
    let mouseY = event.pageY - canvas_tool.offsetTop;

    if (isResizing) {
        let dx = mouseX - start_x;
        let dy = mouseY - start_y;

        tool_shape.width += dx;
        tool_shape.height += dy;

        start_x = mouseX;
        start_y = mouseY;

        draw_tool();
    } else if (isDragging) {
        let dx = mouseX - start_x;
        let dy = mouseY - start_y;

        tool_shape.x += dx;
        tool_shape.y += dy;

        start_x = mouseX;
        start_y = mouseY;

        draw_tool();
    } else {
        resizeHandleHovered = is_mouse_in_resize_handle(mouseX, mouseY);
        draw_tool();
    }
});

canvas_tool.addEventListener('mouseup', function () {
    isDragging = false;
    isResizing = false;
});

function draw_tool() {
    context_tool.clearRect(0, 0, canvas_tool.width, canvas_tool.height);

    if (resizeHandleHovered || isResizing) {
        let handles = getResizeHandles();
        context_tool.fillStyle = "rgba(255, 165, 0, 0.3)";
        for (let handle of handles) {
            context_tool.beginPath();
            context_tool.arc(handle.x, handle.y, resizeHandleRadius, 0, 2 * Math.PI);
            context_tool.fill();
        }
    }

    context_tool.fillStyle = "rgba(255, 165, 0, 0.3)";
    context_tool.fillRect(tool_shape.x, tool_shape.y, tool_shape.width, tool_shape.height);
}

draw_tool();

function reset() {
    tool_shape.x = 100;
    tool_shape.y = 100;
    tool_shape.width = 200;
    tool_shape.height = 200;
    context_tool.clearRect(0, 0, canvas_tool.width, canvas_tool.height);
    context_tool.fillStyle = "rgba(255, 165, 0, 0.3)";
    context_tool.fillRect(100, 100, 200, 200);
};

const btn_reset = document.querySelector("#reset");
btn_reset.addEventListener("click", reset);

function submit() {
    console.log("x: " + tool_shape.x + " y: " + tool_shape.y + " width: " + tool_shape.width + " height: " + tool_shape.height)
};

const btn_submit = document.querySelector("#submit");
btn_submit.addEventListener("click", submit);

// 定義一個全局變數來保存計時器
let timer;

// 啟動計時器
function startTimer() {
    let seconds = 0;
    timer = setInterval(function () {
        seconds++;
        const formattedTime = formatTime(seconds);
        document.getElementById('timer').innerHTML = formattedTime;
    }, 1000);
}

// 格式化時間，將秒數轉換為HH:mm:ss格式
function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}
// 停止計時器
function stopTimer() {
    clearInterval(timer);
}

// 開始計時器
startTimer();

