/* var h1 = document.getElementById("title");
h1.innerText = "CAPTCHA";

function handle_click(ele) {
    ele.innerText = "iii";
} */
/* class Phone {
    constructor(number, year, is_waterproof) {
        this.number = number;
        this.year = year;
        this.is_waterproof = is_waterproof;
    }
    phone_age() {
        return 2021 - this.year;
    }
}

var phone1 = new Phone("123", 1993, false);
var phone2 = new Phone("121", 1943, false);
var phone3 = new Phone("143", 1909, false);
var phone4 = new Phone("163", 1293, false);

document.write(phone1.phone_age()); */
/* var password = 123456;
var input;
var emtry_count = 0;
var emtry_limit = 3;
var emtry_out = false;

while (password != input && !emtry_out) {
    emtry_count++;
    if (emtry_count <= emtry_limit) {
        input = prompt("請輸入密碼");
    }
    else {
        emtry_out = true;
    }
}
if (emtry_out) {
    alert("超過");
}
else {
    alert("成功");
} */